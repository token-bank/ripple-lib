Usage:
babel-node balances.js
babel-node payment.js (requires setting address and secret in source file first)
