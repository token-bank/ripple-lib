import {deriveKeypair, deriveAddress} from 'ripple-keypairs'

export {
  deriveKeypair,
  deriveAddress
}
